# 24adz Admin Panel starter

This project is separate from the current live `24adz.com`. Do not replace or delete the current Cloudflare project until this new project is fully tested.

## Upload to GitHub
Upload the root files (`README.md`, `admin.html`, `index.html`, `schema.sql`) and preserve `functions/[[path]].js` at that exact path. On mobile, GitHub's upload form may not preserve folders; if so, use Add file > Create new file and enter `functions/[[path]].js`, then paste the contents from this file.

## Cloudflare setup
1. Create D1 database `24adz-ads-db`.
2. Create R2 bucket `24adz-ad-images`.
3. Create a NEW Cloudflare Pages project connected to GitHub repo `24adz-admin-panel`. Do not use or change the old `24adz-tiruppur` project. Leave build command empty; set output directory to `.` if required.
4. Run `schema.sql` in the D1 database console.
5. In the new Pages project, add secrets `ADMIN_PASSWORD` (a strong unique password) and `SESSION_SECRET` (a random secret at least 32 characters).
6. Add D1 binding variable `DB` -> `24adz-ads-db`.
7. Add R2 binding variable `IMAGES` -> `24adz-ad-images`.
8. Redeploy after adding bindings/secrets.
9. Test `https://NEW-PROJECT.pages.dev/admin.html`. Do not move `24adz.com` domain yet.

`/api/ads` only returns active and published ads. The live site will not automatically show these ads until it is separately updated to fetch this API.
