const enc = new TextEncoder();
function b64url(bytes){let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
async function hmac(secret,data){const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(data)));}
async function makeToken(secret,exp){const payload=b64url(enc.encode(JSON.stringify({exp})));return payload+'.'+b64url(await hmac(secret,payload));}
async function validSession(req,secret){const c=req.headers.get('Cookie')||'';const m=c.match(/(?:^|;\s*)adz_session=([^;]+)/);if(!m)return false;const p=m[1].split('.');if(p.length!==2)return false;const expected=b64url(await hmac(secret,p[0]));if(expected.length!==p[1].length)return false;let d=0;for(let i=0;i<expected.length;i++)d|=expected.charCodeAt(i)^p[1].charCodeAt(i);if(d)return false;try{const x=JSON.parse(new TextDecoder().decode(fromB64(p[0])));return Number(x.exp)>Date.now()}catch{return false}}
function fromB64(s){s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';const r=atob(s);return Uint8Array.from(r,c=>c.charCodeAt(0));}
function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}})}
function cookie(v,age=28800){return `adz_session=${v}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${age}`}
function bad(msg,status=400){return json({error:msg},status)}
async function auth(req,env){if(!env.SESSION_SECRET)return bad('Cloudflare SESSION_SECRET secret is missing.',500);if(!(await validSession(req,env.SESSION_SECRET)))return bad('Please login first.',401);return null}
function imageUrl(key){return '/api/image?key='+encodeURIComponent(key)}
async function handler({request,env}) {
 const url=new URL(request.url), path=url.pathname, method=request.method;
 if(path==='/api/login'&&method==='POST'){
  if(!env.ADMIN_PASSWORD||!env.SESSION_SECRET)return bad('Cloudflare ADMIN_PASSWORD and SESSION_SECRET secrets are not configured.',500);
  let b;try{b=await request.json()}catch{return bad('Invalid request.')}
  if(typeof b.password!=='string'||b.password!==env.ADMIN_PASSWORD)return bad('Incorrect password.',401);
  const token=await makeToken(env.SESSION_SECRET,Date.now()+8*60*60*1000);
  return json({ok:true},200,{'Set-Cookie':cookie(token)});
 }
 if(path==='/api/logout'&&method==='POST')return json({ok:true},200,{'Set-Cookie':cookie('',0)});
 if(path==='/api/admin/session'&&method==='GET'){const e=await auth(request,env);return e||json({ok:true})}
 if(path==='/api/image'&&method==='GET'){
  if(!env.IMAGES)return bad('R2 binding IMAGES is not configured.',500);
  const key=url.searchParams.get('key')||'';if(!key.startsWith('ads/')||key.includes('..'))return new Response('Not found',{status:404});
  const o=await env.IMAGES.get(key);if(!o)return new Response('Not found',{status:404});
  const h=new Headers();o.writeHttpMetadata(h);h.set('etag',o.httpEtag);h.set('Cache-Control','public, max-age=3600');return new Response(o.body,{headers:h});
 }
 if(path==='/api/ads'&&method==='GET'){
  if(!env.DB)return bad('D1 binding DB is not configured.',500);
  const {results=[]}=await env.DB.prepare("SELECT id,title,description,image_key,age,location,phone,whatsapp,created_at FROM ads WHERE status='active' AND published=1 ORDER BY created_at DESC,id DESC").all();
  return json({ads:results.map(a=>({...a,image_url:a.image_key?imageUrl(a.image_key):null}))},200,{'Cache-Control':'public, max-age=60'});
 }
 if(path==='/api/admin/upload'&&method==='POST'){
  const e=await auth(request,env);if(e)return e;if(!env.IMAGES)return bad('R2 binding IMAGES is not configured.',500);
  const form=await request.formData(), file=form.get('image');if(!file||typeof file.arrayBuffer!=='function')return bad('Choose an image first.');
  if(file.size<1||file.size>5*1024*1024)return bad('Image must be smaller than 5 MB.');
  const types={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif'},ext=types[file.type];if(!ext)return bad('Only JPG, PNG, WEBP or GIF images are allowed.');
  const key=`ads/${crypto.randomUUID()}.${ext}`;await env.IMAGES.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:file.type,cacheControl:'public, max-age=3600'}});return json({ok:true,image_key:key},201);
 }
 if(path==='/api/admin/ads'&&method==='GET'){
  const e=await auth(request,env);if(e)return e;const {results=[]}=await env.DB.prepare('SELECT * FROM ads ORDER BY created_at DESC,id DESC').all();return json({ads:results.map(a=>({...a,published:Number(a.published),image_url:a.image_key?imageUrl(a.image_key):null}))});
 }
 if(path==='/api/admin/ads'&&method==='POST'){
  const e=await auth(request,env);if(e)return e;let b;try{b=await request.json()}catch{return bad('Invalid JSON.')}
  const err=validate(b);if(err)return bad(err);
  const r=await env.DB.prepare('INSERT INTO ads (title,description,image_key,age,location,phone,whatsapp,status,published,updated_at) VALUES (?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(b.title.trim(),b.description||'',b.image_key||null,b.age??null,b.location||'',b.phone||'',b.whatsapp||'',b.status||'inactive',Number(b.published)?1:0).run();return json({ok:true,id:r.meta.last_row_id},201);
 }
 const match=path.match(/^\/api\/admin\/ads\/([0-9]{1,12})$/);
 if(match&&method==='PUT'){
  const e=await auth(request,env);if(e)return e;const id=match[1];let b;try{b=await request.json()}catch{return bad('Invalid JSON.')}
  const err=validate(b);if(err)return bad(err);const old=await env.DB.prepare('SELECT image_key FROM ads WHERE id=?').bind(id).first();if(!old)return bad('Ad not found.',404);
  const key=b.image_key===undefined?old.image_key:(b.image_key||null);
  await env.DB.prepare('UPDATE ads SET title=?,description=?,image_key=?,age=?,location=?,phone=?,whatsapp=?,status=?,published=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(b.title.trim(),b.description||'',key,b.age??null,b.location||'',b.phone||'',b.whatsapp||'',b.status,Number(b.published),id).run();return json({ok:true});
 }
 if(match&&method==='DELETE'){
  const e=await auth(request,env);if(e)return e;const id=match[1];const old=await env.DB.prepare('SELECT image_key FROM ads WHERE id=?').bind(id).first();if(!old)return bad('Ad not found.',404);await env.DB.prepare('DELETE FROM ads WHERE id=?').bind(id).run();if(old.image_key&&env.IMAGES){try{await env.IMAGES.delete(old.image_key)}catch{}}return json({ok:true});
 }
 return bad('Not found.',404);
}
function validate(b){if(!b||typeof b.title!=='string'||!b.title.trim())return 'Ad title is required.';if(b.title.length>160)return 'Title too long.';if(b.description&&b.description.length>5000)return 'Description too long.';if(b.age!==null&&b.age!==undefined&&(!Number.isInteger(b.age)||b.age<18||b.age>120))return 'Age must be between 18 and 120.';if(!['active','inactive'].includes(b.status||'inactive'))return 'Invalid status.';if(![0,1].includes(Number(b.published)))return 'Invalid publish setting.';for(const k of ['location','phone','whatsapp','image_key'])if(b[k]&&String(b[k]).length>500)return 'Field too long.';return null}
export async function onRequest(ctx){try{return await handler(ctx)}catch(e){return json({error:'Server error. Check Cloudflare bindings and D1 schema.'},500)}}
